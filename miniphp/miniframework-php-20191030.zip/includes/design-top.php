<header class="header">
    <div class="container">
      <h1 class="site-title">Super Cool PHP Website!</h1>
    <span class="site-tagline">Because flexbox and php is super cool!</span>
  </div>
</header>

<footer class="footer">
  <div class="container">
    <p>&copy; <?php print date("Y");?> Alberto de Alarcón Sánchez.</p>
  </div>
</footer>

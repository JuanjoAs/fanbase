<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html>
<head>
	<?php include("includes/head-tag-contents.php");?>
</head>
<body>

<?php include("includes/design-top.php");?>
<?php include("includes/navigation.php");?>


<main>
<section class="content">
  <div class="full-bleed cool-photo">
  </div>
</section>
</main>

<?php include("includes/footer.php");?>

</body>
</html>